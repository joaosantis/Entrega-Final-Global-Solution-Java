package br.com.fiap.synapse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SynapseApplicationTests {

	@Test
	void contextLoads() {
	}

}
